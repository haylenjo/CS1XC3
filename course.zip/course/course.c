/**
 * @file course.c
 * @author Haylen Jo (joh6@mcmaster.ca)
 * @brief A Library for codes regarding courses
 * @version 0.1
 * @date 2022-04-05
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 

 /**
  * @brief It increases the number of total students in the course, and restores the list of students in the Course.
  * 
  * @param course : It receives the 'Course' the students will take.
  * @param student : It receives the 'Student' who will take the course
  */
void enroll_student(Course *course, Student *student)
{
  //increases the number of total students in the course
  course->total_students++;
  //To enroll the first student in the course, we use calloc, and for others we use realloc.
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Print the information about the courses.
 * 
 * @param course : It receives the course to print out the information.
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //Print all students in the list.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Finds the top student in the course.
 * 
 * @param course : It receives the course we want to find the top student of.
 * @return Student* : It returns the student who is the top of the course.
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  //Finding the student who has the highest average.
  //Set the max average as the first student's average, then change the max average by comparing it to the next person.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Check the students who passed the course.
 * 
 * @param course : It receives the 'Course' to see who passed in that course.
 * @param total_passing : It gives the address that stores the 'int' value
 * @return Student* : It returns the list of students passing the course.
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //Check if the average is over 50 for all students in the course and find the number of the passing students.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //Using calloc, it allocates the space for passing students with the number of total students who passed(count).
  passing = calloc(count, sizeof(Student));

  // Add a student who passed the course(the average is greater or equal to 50) to the passing list.
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}