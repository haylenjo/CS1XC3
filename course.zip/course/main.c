/**
 * @file main.c
 * @author Haylen Jo (joh6@mcmaster.ca)
 * @brief Main function for class(courses and students).
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief Enroll students in the class 'MATH 101', and print the courses, top student, students in the class, the number of student passing, and the list of passing students.
 * 
 * @return int 
 */
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //Enroll a student to the class with 8 grades(the number of grades).
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  //print all students (who passed) in the passing students list.
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}