/**
 * @file course.h
 * @author Haylen Jo (joh6@mcmaster.ca)
 * @brief defines the type "Course"
 * @version 0.1
 * @date 2022-04-05
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include "student.h"
#include <stdbool.h>
 
 /**
  * @brief It stores courses' name, code, Student, and the total number of students in the type 'Course'.
  * 
  */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

//It combines all functions in c file.
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


