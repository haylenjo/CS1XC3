/**
 * @file student.h
 * @author Haylen Jo (joh6@mcmaster.ca)
 * @brief defines the type 'Student'
 * @version 0.1
 * @date 2022-04-05
 * 
 * @copyright Copyright (c) 2022
 * 
 */


/**
 * @brief It stores students' name, id, and grades in the type 'Student'.
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

//It combines functions in c file.
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
